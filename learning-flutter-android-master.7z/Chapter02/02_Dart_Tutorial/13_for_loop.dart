void main(){ 
  for(int i=0; i<10; i++){
    print(i);
  }

  var myList = ["a","b","c"];
  for(var i in myList){ 
    print(i); 
  } 
}

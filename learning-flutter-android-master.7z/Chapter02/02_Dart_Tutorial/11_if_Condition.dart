void main(){
  int score = 80;
  
  if(score >= 60){
    print("합격!");
  }
  else{
    print("불합격!");
  }
  
  if(score >= 90){
    print("A");
  }
  else if(score >= 80){
    print("B");
  }
  else if(score >= 70){
    print("C");
  }
  else{
    print("D");
  }
}
void main(){ 
  try{ 
    var res = 100;
    print(res); 
  } 
  catch(e){ 
    print(e); 
  } 
  finally{ 
    print('Done'); 
  } 
} 

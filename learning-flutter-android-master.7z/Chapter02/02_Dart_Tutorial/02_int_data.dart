void main() {
  int a = 1;
  print(a);
  print(a.runtimeType);
  
  double b = 1.3333;
  print(b);
  print(b.runtimeType);
}
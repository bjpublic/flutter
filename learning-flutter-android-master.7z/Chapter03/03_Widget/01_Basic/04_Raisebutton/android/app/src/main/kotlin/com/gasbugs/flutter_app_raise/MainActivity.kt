package com.gasbugs.flutter_app_raise

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.gasbugs.flutter_app_scrollbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.gasbugs.flutter_app_divider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.gasbugs.flutter_app_listtile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

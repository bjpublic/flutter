package com.gasbugs.flutter_app_bottomsheet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.gasbugs.flutter_app_stack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

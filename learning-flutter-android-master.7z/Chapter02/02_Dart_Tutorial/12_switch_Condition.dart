void main(){ 
  var condition = 1;
  switch(condition){
    case 1:
      print("하나입니다.");
      break;
    case 2:
      print("둘입니다.");
      break;
    case 3:
      print("셋입니다.");
      break;
    default:
      print("기본 값입니다.");
  }
}
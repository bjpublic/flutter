void main() { 
  var myMap = {"Gun":18, "Mina":20, "Kevin":32}; 
 
  print("map의 길이: ${myMap.length}"); 
  print("map의 자료형: ${myMap.runtimeType}"); 
  print("map의 데이터: ${myMap}"); 
  
  print("맵의 키들: ${myMap.keys}"); 
  print("맵의 값들: ${myMap.values}"); 
}

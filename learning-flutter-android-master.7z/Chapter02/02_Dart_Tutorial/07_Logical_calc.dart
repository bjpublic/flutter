void main(){ 
  bool a = true; 
  bool b = false; 
  
  print(a.runtimeType); 
  print(a || b); 
  print(a && b); 
  print(!a); 
}

void main(){ 
  print('First'); 
  print(get()); 
  print('Third'); 
} 
String get(){ 
  return 'Second'; 
} 

void main(){ 
  while(true){
    break;
    print("실행됨");
  }
}

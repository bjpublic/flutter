package com.gasbugs.flutter_container_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

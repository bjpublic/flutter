package com.gasbugs.flutter_app_layout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

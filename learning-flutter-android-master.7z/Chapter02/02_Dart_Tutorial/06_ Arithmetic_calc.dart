void main() {
  int a = 1;
  int b = 3;
  
  print(a + b);
  print(a - b);
  print(a * b);
  print(a / b);
  print(a ~/ b);
  print(-a);
}
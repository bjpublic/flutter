package com.gasbugs.flutter_app_bottomnav

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

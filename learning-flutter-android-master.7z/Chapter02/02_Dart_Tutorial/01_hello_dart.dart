/*
print 함수를 사용해 문자열을 출력합니다.
출력하는 문장은 Hello World!입니다. 
*/

void main() { //main이라는 함수를 사용할 겁니다.
  print("Hello World!"); //print 함수를 사용해 문자열을 출력!
}

package com.gasbugs.flutter_app_sliverappbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

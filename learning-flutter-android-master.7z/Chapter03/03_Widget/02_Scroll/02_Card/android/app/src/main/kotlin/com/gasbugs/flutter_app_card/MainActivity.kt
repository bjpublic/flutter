package com.gasbugs.flutter_app_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

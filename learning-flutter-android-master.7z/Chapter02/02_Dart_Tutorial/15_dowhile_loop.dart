void main(){ 
  int i = 0;
  
  do {
    print("실행됨");
  } while(i!=0);
}

package com.gasbugs.flutter_app_scroll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

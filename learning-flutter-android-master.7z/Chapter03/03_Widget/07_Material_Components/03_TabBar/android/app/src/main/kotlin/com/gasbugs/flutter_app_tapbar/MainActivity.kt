package com.gasbugs.flutter_app_tapbar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

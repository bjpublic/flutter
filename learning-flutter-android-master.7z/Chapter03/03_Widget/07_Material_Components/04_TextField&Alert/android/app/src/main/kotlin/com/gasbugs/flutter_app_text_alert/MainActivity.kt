package com.gasbugs.flutter_app_text_alert

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
